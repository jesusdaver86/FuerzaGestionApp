<footer class="main-footer">
	
	<strong>Copyright &copy; <script type="text/javascript">
	var d = new Date()
	document.write(d.getFullYear())
	</script>  <a href="#" target="_blank">TTOcc</a>.</strong>

	Todos los derechos reservados.


</footer>