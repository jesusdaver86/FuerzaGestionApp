/*function fadeOutAfterDelay(element) {

  setTimeout(() => {

    element.style.opacity = 10;

  }, 3000);

} */
